"""Simple Online Voting System built with Flask and SQLite."""
import os
import sqlite3
from functools import wraps

from flask import (Flask, flash, g, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-change-me")
app.config["DATABASE"] = os.path.join(app.instance_path, "voting.db")
os.makedirs(app.instance_path, exist_ok=True)

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_admin INTEGER NOT NULL DEFAULT 0,
    has_voted INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT
);
CREATE TABLE IF NOT EXISTS votes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_id INTEGER NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


# ---------- Database helpers ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create tables, a default admin account and the 'voting open' flag."""
    db = sqlite3.connect(app.config["DATABASE"])
    db.executescript(SCHEMA)
    admin_pw = os.environ.get("ADMIN_PASSWORD", "admin123")
    db.execute(
        "INSERT OR IGNORE INTO users (username, password_hash, is_admin) "
        "VALUES (?, ?, 1)", ("admin", generate_password_hash(admin_pw)))
    db.execute("INSERT OR IGNORE INTO settings (key, value) "
               "VALUES ('voting_open', '1')")
    db.commit()
    db.close()


def voting_open():
    row = get_db().execute(
        "SELECT value FROM settings WHERE key='voting_open'").fetchone()
    return bool(row and row["value"] == "1")


# ---------- Auth helpers ----------
@app.before_request
def load_user():
    uid = session.get("user_id")
    g.user = None
    if uid is not None:
        g.user = get_db().execute(
            "SELECT * FROM users WHERE id=?", (uid,)).fetchone()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            flash("Please log in first.", "error")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if not g.user["is_admin"]:
            flash("Admin access only.", "error")
            return redirect(url_for("index"))
        return view(*args, **kwargs)
    return wrapped


# ---------- Public routes ----------
@app.route("/")
def index():
    return render_template("index.html", is_open=voting_open())


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        error = None
        if len(username) < 3:
            error = "Username must be at least 3 characters."
        elif len(password) < 6:
            error = "Password must be at least 6 characters."
        if error is None:
            try:
                db = get_db()
                db.execute(
                    "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                    (username, generate_password_hash(password)))
                db.commit()
                flash("Registration successful. Please log in.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                error = "That username is already taken."
        flash(error, "error")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = get_db().execute(
            "SELECT * FROM users WHERE username=?",
            (request.form["username"].strip(),)).fetchone()
        if user and check_password_hash(user["password_hash"],
                                        request.form["password"]):
            session.clear()
            session["user_id"] = user["id"]
            flash(f"Welcome, {user['username']}!", "success")
            return redirect(url_for("index"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("index"))


# ---------- Voting ----------
@app.route("/vote", methods=["GET", "POST"])
@login_required
def vote():
    db = get_db()
    if g.user["has_voted"]:
        flash("You have already voted. Thank you!", "error")
        return redirect(url_for("results"))
    if not voting_open():
        flash("Voting is currently closed.", "error")
        return redirect(url_for("index"))
    candidates = db.execute("SELECT * FROM candidates ORDER BY name").fetchall()
    if request.method == "POST":
        cid = request.form.get("candidate_id", type=int)
        if not any(c["id"] == cid for c in candidates):
            flash("Please select a valid candidate.", "error")
        else:
            # One transaction: record the vote and mark the voter together.
            # Votes are stored without user ids, so ballots stay anonymous.
            db.execute("INSERT INTO votes (candidate_id) VALUES (?)", (cid,))
            db.execute("UPDATE users SET has_voted=1 WHERE id=?",
                       (g.user["id"],))
            db.commit()
            flash("Your vote has been recorded.", "success")
            return redirect(url_for("results"))
    return render_template("vote.html", candidates=candidates)


@app.route("/results")
def results():
    rows = get_db().execute(
        "SELECT c.name, c.description, COUNT(v.id) AS total "
        "FROM candidates c LEFT JOIN votes v ON v.candidate_id = c.id "
        "GROUP BY c.id ORDER BY total DESC, c.name").fetchall()
    grand_total = sum(r["total"] for r in rows)
    return render_template("results.html", rows=rows, grand_total=grand_total)


# ---------- Admin ----------
@app.route("/admin")
@admin_required
def admin():
    db = get_db()
    candidates = db.execute("SELECT * FROM candidates ORDER BY name").fetchall()
    stats = db.execute(
        "SELECT COUNT(*) AS voters, SUM(has_voted) AS voted "
        "FROM users WHERE is_admin=0").fetchone()
    return render_template("admin.html", candidates=candidates, stats=stats,
                           is_open=voting_open())


@app.route("/admin/add", methods=["POST"])
@admin_required
def add_candidate():
    name = request.form["name"].strip()
    if not name:
        flash("Candidate name is required.", "error")
    else:
        try:
            db = get_db()
            db.execute("INSERT INTO candidates (name, description) VALUES (?, ?)",
                       (name, request.form.get("description", "").strip()))
            db.commit()
            flash(f"Added candidate {name}.", "success")
        except sqlite3.IntegrityError:
            flash("Candidate already exists.", "error")
    return redirect(url_for("admin"))


@app.route("/admin/delete/<int:cid>", methods=["POST"])
@admin_required
def delete_candidate(cid):
    db = get_db()
    db.execute("DELETE FROM candidates WHERE id=?", (cid,))
    db.commit()
    flash("Candidate removed.", "success")
    return redirect(url_for("admin"))


@app.route("/admin/toggle", methods=["POST"])
@admin_required
def toggle_voting():
    db = get_db()
    new_value = "0" if voting_open() else "1"
    db.execute("UPDATE settings SET value=? WHERE key='voting_open'",
               (new_value,))
    db.commit()
    flash("Voting opened." if new_value == "1" else "Voting closed.", "success")
    return redirect(url_for("admin"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
