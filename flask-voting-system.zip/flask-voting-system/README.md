# Online Voting System (Flask Mini Project)

A simple web-based voting system built with **Python, Flask and SQLite**.
Voters register, log in and cast exactly one vote. An admin manages candidates
and opens or closes voting. Results are shown live as bar charts.

## Features
- User registration and login (passwords hashed with Werkzeug)
- One vote per user, enforced on the server
- Anonymous ballots (votes are stored without user ids)
- Admin panel: add/remove candidates, open/close voting, turnout stats
- Public results page with percentages
- Automated tests (`test_app.py`)

## Project structure
```
flask-voting-system/
├── app.py              # Flask application (routes, database logic)
├── test_app.py         # Unit tests
├── requirements.txt
├── static/style.css
├── templates/          # Jinja2 HTML templates
└── docs/
    ├── Project_Report.pdf
    └── Case_Study.pdf
```

## Setup
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Default admin
Username `admin`, password `admin123`.
**Change it** before any real use:
```bash
export ADMIN_PASSWORD="your-strong-password"   # set before the first run
export SECRET_KEY="a-long-random-string"
```

## Run tests
```bash
python test_app.py
```

## Limitations / future work
Not production-ready: no CSRF protection, no email/ID verification, no
rate limiting, SQLite only. See `docs/Project_Report.pdf` for details.

## License
MIT (add a LICENSE file if you publish).
