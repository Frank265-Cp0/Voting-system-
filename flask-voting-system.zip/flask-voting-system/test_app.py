"""Basic tests. Run with:  python -m pytest   (or)   python test_app.py"""
import os
import tempfile
import unittest

import app as voting


class VotingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.tmp.close()
        voting.app.config.update(DATABASE=self.tmp.name, TESTING=True)
        voting.init_db()
        self.client = voting.app.test_client()

    def tearDown(self):
        os.unlink(self.tmp.name)

    def login(self, user, pw):
        return self.client.post("/login", data={"username": user, "password": pw},
                                follow_redirects=True)

    def test_full_flow(self):
        # admin adds candidates
        self.login("admin", "admin123")
        self.client.post("/admin/add", data={"name": "Alice"})
        self.client.post("/admin/add", data={"name": "Bob"})
        self.client.get("/logout")
        # voter registers and votes
        self.client.post("/register", data={"username": "voter1", "password": "secret1"})
        self.login("voter1", "secret1")
        resp = self.client.post("/vote", data={"candidate_id": 1}, follow_redirects=True)
        self.assertIn(b"vote has been recorded", resp.data)
        # second vote is rejected
        resp = self.client.post("/vote", data={"candidate_id": 2}, follow_redirects=True)
        self.assertIn(b"already voted", resp.data)
        self.assertIn(b"Total votes: <strong>1</strong>", self.client.get("/results").data)

    def test_vote_requires_login(self):
        resp = self.client.get("/vote", follow_redirects=True)
        self.assertIn(b"Please log in first", resp.data)

    def test_admin_protected(self):
        self.client.post("/register", data={"username": "voter2", "password": "secret2"})
        self.login("voter2", "secret2")
        resp = self.client.get("/admin", follow_redirects=True)
        self.assertIn(b"Admin access only", resp.data)

    def test_closed_voting(self):
        self.login("admin", "admin123")
        self.client.post("/admin/add", data={"name": "Alice"})
        self.client.post("/admin/toggle")
        self.client.get("/logout")
        self.client.post("/register", data={"username": "voter3", "password": "secret3"})
        self.login("voter3", "secret3")
        resp = self.client.get("/vote", follow_redirects=True)
        self.assertIn(b"Voting is currently closed", resp.data)


if __name__ == "__main__":
    unittest.main()
